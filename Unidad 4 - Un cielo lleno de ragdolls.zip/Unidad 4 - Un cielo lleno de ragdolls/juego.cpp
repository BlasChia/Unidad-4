#include "juego.h"

juego::juego(Vector2i resolucion, std::string titulo) {

	fps = 60;
	tFrame = 1 / 60.f;
	tiempo2 = 0;

	ventana1 = new RenderWindow(VideoMode(resolucion.x, resolucion.y), titulo);
	ventana1->setFramerateLimit(fps);

	est_camara();
	inic_fisica();
	inic_objetos();

	evento1 = new Event;

	reloj1 = new Clock;
	tiempo1 = new Time;

	actor_canon = new actor(body_canon, fig_canon);
	actor_estat = new actor(body_estat, fig_estat);
	actor_dinam = new actor(body_dinam, fig_dinam);

	for (int i = 0; i < 4; i++) {

		actor_bordes[i] = new actor(body_bordes[i], fig_bordes[i]);

	}

	gLoop();

}

void juego::est_camara() {

	camara1 = new View({ 7.5f, 7.5f }, { 15.f, 15.f });

	camara1->move(42.5f, 85.f);

	ventana1->setView(*camara1);

}

void juego::inic_fisica() {

	mundo1 = new b2World(b2Vec2(0.f, 9.81f));

	bodydef_canon.type = b2_staticBody;
	bodydef_canon.position = b2Vec2(44.f, 97.5f);

	body_canon = mundo1->CreateBody(&bodydef_canon);

	b2PolygonShape forma_canon;
	forma_canon.SetAsBox(0.85f, 0.4f);

	fixdef_canon.shape = &forma_canon;
	fixdef_canon.restitution = 0.f;
	fixdef_canon.friction = 0.3f;
	fixdef_canon.density = 1.f;

	fix_canon = body_canon->CreateFixture(&fixdef_canon);

	bodydef_estat.type = b2_staticBody;
	bodydef_estat.position = b2Vec2(54.f, 98.f);

	body_estat = mundo1->CreateBody(&bodydef_estat);

	b2PolygonShape forma_estat;
	forma_estat.SetAsBox(2.f, 4.f);

	fixdef_estat.shape = &forma_estat;
	fixdef_estat.restitution = 0.f;
	fixdef_estat.friction = 0.3f;
	fixdef_estat.density = 1.f;

	fix_estat = body_estat->CreateFixture(&fixdef_estat);

	bodydef_dinam.type = b2_dynamicBody;
	bodydef_dinam.position = b2Vec2(54.f, 93.f);

	body_dinam = mundo1->CreateBody(&bodydef_dinam);

	b2PolygonShape forma_dinam;
	forma_dinam.SetAsBox(1.f, 1.f);

	fixdef_dinam.shape = &forma_dinam;
	fixdef_dinam.restitution = 0.f;
	fixdef_dinam.friction = 0.3f;
	fixdef_dinam.density = 1.f;

	fix_dinam = body_dinam->CreateFixture(&fixdef_dinam);

	bodydef_bordes[0].position = b2Vec2(40.5f, 50.f);
	bodydef_bordes[1].position = b2Vec2(59.5f, 50.f);
	bodydef_bordes[2].position = b2Vec2(50.f, 83.05f);
	bodydef_bordes[3].position = b2Vec2(50.f, 101.f);

	for (int i = 0; i < 4; i++) {

		bodydef_bordes[i].type = b2_staticBody;
		body_bordes[i] = mundo1->CreateBody(&bodydef_bordes[i]);

	}

	b2PolygonShape forma_bordes[4];

	forma_bordes[0].SetAsBox(2.f, 50.f);
	forma_bordes[1].SetAsBox(2.f, 50.f);
	forma_bordes[2].SetAsBox(50.f, 2.f);
	forma_bordes[3].SetAsBox(50.f, 2.f);

	for (int i = 0; i < 4; i++) {

		fixdef_bordes[i].shape = &forma_bordes[i];
		fixdef_bordes[i].density = 1.f;
		fixdef_bordes[i].friction = 0.3f;
		fixdef_bordes[i].restitution = 0.1f;

		fix_bordes[i] = body_bordes[i]->CreateFixture(&fixdef_bordes[i]);

	}

}

void juego::inic_objetos() {

	fig_canon = new RectangleShape;

	fig_estat = new RectangleShape;

	fig_dinam = new RectangleShape;

	for (int i = 0; i < 4; i++) {

		fig_bordes[i] = new RectangleShape;

	}

	fig_canon->setFillColor(Color::Cyan);
	fig_estat->setFillColor(Color::Magenta);
	fig_dinam->setFillColor(Color::Yellow);

	fig_bordes[0]->setFillColor(Color::Green);
	fig_bordes[1]->setFillColor(Color::Green);
	fig_bordes[2]->setFillColor(Color::Green);
	fig_bordes[3]->setFillColor(Color::Green);

}

void juego::act_fisica() {

	mundo1->Step(tFrame, 8, 8);

	mundo1->ClearForces();

}

void juego::proc_eventos() {

	while (ventana1->pollEvent(*evento1)) {

		switch (evento1->type) {

		case Event::Closed:

			exit(1);

			break;

		case Event::KeyPressed:

			if (Keyboard::isKeyPressed(Keyboard::Left)) {

				body_canon->SetTransform(body_canon->GetPosition(), body_canon->GetAngle() + deg2rad(-3));

			}

			else if (Keyboard::isKeyPressed(Keyboard::Right)) {

				body_canon->SetTransform(body_canon->GetPosition(), body_canon->GetAngle() + deg2rad(3));

			}

			break;

		case Event::MouseButtonPressed:

			Vector2i pos_mouse;
			Vector2f pos_mouseCo;

			pos_mouse = Mouse::getPosition(*ventana1);

			pos_mouseCo = ventana1->mapPixelToCoords(pos_mouse);

			body_canon->SetTransform(body_canon->GetPosition(), atan2f(pos_mouseCo.y - body_canon->GetPosition().y, pos_mouseCo.x - body_canon->GetPosition().x));

			for (int i = 0; i < 5; i++) {

				rag_1[i] = new ragdoll({ body_canon->GetPosition().x + 0.85f, body_canon->GetPosition().y }, *mundo1);

				rag_1[i]->aplicar_fuerza({ pos_mouseCo.x - body_canon->GetPosition().x, pos_mouseCo.y - body_canon->GetPosition().y });

			}

			break;

		}

	}

}

void juego::gLoop() {

	while (ventana1->isOpen()) {

		*tiempo1 = reloj1->getElapsedTime();

		if (tiempo2 + tFrame < tiempo1->asSeconds()) {

			tiempo2 = tiempo1->asSeconds();

			ventana1->clear();

			proc_eventos();

			act_fisica();

			dibujar();

			ventana1->display();

		}

	}

}

void juego::dibujar() {

	actor_canon->dibujar(*ventana1);
	actor_estat->dibujar(*ventana1);
	actor_dinam->dibujar(*ventana1);

	for (int i = 0; i < 4; i++) {

		actor_bordes[i]->dibujar(*ventana1);

	}

	//Este fragmento inferior

	for (int i = 0; i < 5; i++) {

		rag_1[i]->dibujar(*ventana1);

	}

	//No logro comprender porque al momento de a�adir la funci�n para dibujar los ragdolls genera el siguiente error en ragdoll.cpp: 
	//Excepci�n no controlada en 0x00007FF75ACA388E en Ejercicio 5 - Unidad 3.exe: 0xC0000005: Infracci�n de acceso al leer la ubicaci�n 0xFFFFFFFFFFFFFFFF.
	//Esto se genera en la linea:	actor_cuerpo[i]->dibujar(ventana1); 
	//He probado de diferentes maneras intentar arreglarlo, pero no he dado con la clave para ello.
	//Si quito las lineas se�aladas los ragdolls se generan pero no se ven.

}

float juego::deg2rad(float grados) {

	return grados * 3.14f / 180.f;

}