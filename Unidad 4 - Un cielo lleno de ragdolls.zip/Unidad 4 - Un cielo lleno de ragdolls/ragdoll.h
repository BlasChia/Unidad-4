#pragma once
#include "actor.h"


class ragdoll
{
public:

	ragdoll(Vector2f posicion, b2World& mundo1);
	void dibujar(RenderWindow& ventana);
	void aplicar_fuerza(Vector2f pos_mouse);
	float rad2deg(float radianes);

private:

	RectangleShape* fig_cuerpo[6];
	actor* actor_cuerpo[6];

	b2DistanceJoint* union_cuerpo[5];
	b2DistanceJointDef uniondef_cuerpo[5];

	b2Body* body_cuerpo[6];
	b2BodyDef bodydef_cuerpo[6];
	b2Fixture* fix_cuerpo[6];
	b2FixtureDef fixdef_cuerpo[6];

};

