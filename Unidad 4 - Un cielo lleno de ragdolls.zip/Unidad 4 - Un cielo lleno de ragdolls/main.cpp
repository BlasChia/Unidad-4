#include "juego.h"



int main(int argc, char* argv[]) {

	juego partida({ 800, 600 }, "Ejercicio 5");

	return 0;

}