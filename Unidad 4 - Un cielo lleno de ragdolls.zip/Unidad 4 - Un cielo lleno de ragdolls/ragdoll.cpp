#include "ragdoll.h"
#include <iostream>


ragdoll::ragdoll(Vector2f posicion, b2World& mundo1) {


	bodydef_cuerpo[0].position = b2Vec2(posicion.x, posicion.y + 0.1);
	bodydef_cuerpo[1].position = b2Vec2(posicion.x, posicion.y + 0.65);
	bodydef_cuerpo[2].position = b2Vec2(posicion.x + 0.32, posicion.y + 0.5);
	bodydef_cuerpo[3].position = b2Vec2(posicion.x - 0.32, posicion.y + 0.5);
	bodydef_cuerpo[4].position = b2Vec2(posicion.x + 0.09, posicion.y + 1.5);
	bodydef_cuerpo[5].position = b2Vec2(posicion.x - 0.09, posicion.y + 1.5);

	for (int i = 0; i < 6; i++) {

		bodydef_cuerpo[i].type = b2_dynamicBody;
		body_cuerpo[i] = mundo1.CreateBody(&bodydef_cuerpo[i]);

	}

	b2PolygonShape forma_cuerpo[6];

	forma_cuerpo[0].SetAsBox(0.1, 0.1);
	forma_cuerpo[1].SetAsBox(0.2, 0.4);
	forma_cuerpo[2].SetAsBox(0.07, 0.3);
	forma_cuerpo[3].SetAsBox(0.07, 0.3);
	forma_cuerpo[4].SetAsBox(0.07, 0.4);
	forma_cuerpo[5].SetAsBox(0.07, 0.4);

	for (int i = 0; i < 6; i++) {

		fixdef_cuerpo[i].shape = &forma_cuerpo[i];
		fixdef_cuerpo[i].density = 1.f;
		fixdef_cuerpo[i].friction = 0.3f;
		fixdef_cuerpo[i].restitution = 0.1f;

		fix_cuerpo[i] = body_cuerpo[i]->CreateFixture(&fixdef_cuerpo[i]);

	}

	uniondef_cuerpo[0].Initialize(body_cuerpo[0], body_cuerpo[1], b2Vec2(body_cuerpo[0]->GetPosition().x, body_cuerpo[0]->GetPosition().y + 0.08), b2Vec2(body_cuerpo[1]->GetPosition().x, body_cuerpo[1]->GetPosition().y - 0.38));
	uniondef_cuerpo[1].Initialize(body_cuerpo[1], body_cuerpo[2], b2Vec2(body_cuerpo[1]->GetPosition().x + 0.18, body_cuerpo[1]->GetPosition().y - 0.38), b2Vec2(body_cuerpo[2]->GetPosition().x - 0.05, body_cuerpo[2]->GetPosition().y - 0.28));
	uniondef_cuerpo[2].Initialize(body_cuerpo[1], body_cuerpo[3], b2Vec2(body_cuerpo[1]->GetPosition().x - 0.18, body_cuerpo[1]->GetPosition().y - 0.38), b2Vec2(body_cuerpo[3]->GetPosition().x + 0.05, body_cuerpo[3]->GetPosition().y - 0.28));
	uniondef_cuerpo[3].Initialize(body_cuerpo[1], body_cuerpo[4], b2Vec2(body_cuerpo[1]->GetPosition().x + 0.09, body_cuerpo[1]->GetPosition().y + 0.38), b2Vec2(body_cuerpo[4]->GetPosition().x, body_cuerpo[4]->GetPosition().y - 0.38));
	uniondef_cuerpo[4].Initialize(body_cuerpo[1], body_cuerpo[5], b2Vec2(body_cuerpo[1]->GetPosition().x + 0.09, body_cuerpo[1]->GetPosition().y + 0.08), b2Vec2(body_cuerpo[5]->GetPosition().x, body_cuerpo[5]->GetPosition().y - 0.38));

	for (int i = 0; i < 5; i++) {

		uniondef_cuerpo[i].damping = 0.3f;
		uniondef_cuerpo[i].collideConnected = true;

		union_cuerpo[i] = (b2DistanceJoint*)mundo1.CreateJoint(&uniondef_cuerpo[i]);

	}

	for (int i = 0; i < 6; i++) {

		fig_cuerpo[i] = new RectangleShape;

	}

	fig_cuerpo[0]->setFillColor(Color::White);
	fig_cuerpo[1]->setFillColor(Color::Red);
	fig_cuerpo[2]->setFillColor(Color::Red);
	fig_cuerpo[3]->setFillColor(Color::Red);
	fig_cuerpo[4]->setFillColor(Color::Blue);
	fig_cuerpo[5]->setFillColor(Color::Blue);

	for (int i = 0; i < 6; i++) {

		actor_cuerpo[i] = new actor(body_cuerpo[i], fig_cuerpo[i]);

	}

}


void ragdoll::dibujar(RenderWindow& ventana1) {

	for (int i = 0; i < 6; i++) {

		actor_cuerpo[i]->dibujar(ventana1);

	}

}

void ragdoll::aplicar_fuerza(Vector2f pos_mouse) {

	for (int i = 0; i < 6; i++) {

		body_cuerpo[i]->ApplyForceToCenter(b2Vec2(pos_mouse.x * 25, pos_mouse.y * 25), false);

	}

}

float ragdoll::rad2deg(float radianes) {

	return radianes * 180.f / 3.14f;

}