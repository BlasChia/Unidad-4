#pragma once
#include "actor.h"
#include "ragdoll.h"	


class juego
{
public:

	juego(Vector2i resolucion, std::string titulo);
	void est_camara();
	void inic_fisica();
	void inic_objetos();
	void act_fisica();
	void proc_eventos();
	void gLoop();
	void dibujar();
	float deg2rad(float grados);


private:

	RenderWindow* ventana1;
	View* camara1;

	Event* evento1;

	Time* tiempo1;
	Clock* reloj1;

	float fps, tFrame, tiempo2;

	b2World* mundo1;

	b2Body* body_canon;
	b2BodyDef bodydef_canon;
	b2Fixture* fix_canon;
	b2FixtureDef fixdef_canon;

	b2Body* body_estat;
	b2BodyDef bodydef_estat;
	b2Fixture* fix_estat;
	b2FixtureDef fixdef_estat;

	b2Body* body_dinam;
	b2BodyDef bodydef_dinam;
	b2Fixture* fix_dinam;
	b2FixtureDef fixdef_dinam;

	b2Body* body_bordes[4];
	b2BodyDef bodydef_bordes[4];
	b2Fixture* fix_bordes[4];
	b2FixtureDef fixdef_bordes[4];

	RectangleShape* fig_bordes[4];
	RectangleShape* fig_canon;
	RectangleShape* fig_estat;
	RectangleShape* fig_dinam;

	actor* actor_bordes[4];
	actor* actor_canon;
	actor* actor_estat;
	actor* actor_dinam;

	ragdoll* rag_1[5];

};

